import React from 'react';
import styles from './LoginSelector.module.css';

const LoginSelector = () => {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className={styles.pageContainer}>
      <div
        className={styles.body}
        style={{
          backgroundColor: '#000',
          backgroundImage: "url('/niamtlogo3.png')",
          backgroundSize: '500px',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center 80px',
          backgroundAttachment: 'fixed',
        }}
      >
        {/* ✅ Top-Left Date */}
        <div className={styles.dateCard}>{currentDate}</div>

        {/* ✅ Navbar */}
        <nav className={styles.navbar}>
          <ul className={styles.navList}>
            <li><a href="/" className={styles.navLink}>Home</a></li>
            <li><a href="/admission" className={styles.navLink}>Admission</a></li>
            <li><a href="/about" className={styles.navLink}>About</a></li>
          </ul>
        </nav>

        {/* ✅ Main Content */}
        <main className={styles.loginWrapper}>
          <h1>Select Login Type</h1>

          <div className={styles.buttonSections}>
            <div className={styles.buttonSection}>
              <a href="/student-login" className={`${styles.loginBtn} ${styles.student}`}>
                <img src="/icon-profile.png" alt="Student Icon" className={styles.buttonIcon} />
                <span>Login as a Student</span>
              </a>
            </div>

            <div className={styles.buttonSection}>
              <a href="/faculty-login" className={`${styles.loginBtn} ${styles.faculty}`}>
                <img src="/icon-profile.png" alt="Faculty Icon" className={styles.buttonIcon} />
                <span>Login as a Faculty/Admin</span>
              </a>
            </div>
          </div>
        </main>
      </div>

      {/* ✅ Footer */}
      <footer className={styles.footer}>
        <p>Contact us: <a href="mailto:barnwalgourav547@gmail.com">barnwalgourav547@gmail.com</a></p>
        <p>Phone: <a href="tel:8809210035">8809210035</a></p>
      </footer>
    </div>
  );
};

export default LoginSelector;
